# 📦 批量运行工具使用指南

**工具**: `run_batch_experiments.py`  
**功能**: 智能化批量运行参数敏感性分析实验

---

## 🎯 核心特性

- ✅ **交互式选择** - 友好的菜单界面
- ✅ **预设模式** - quick/medium/full三种模式
- ✅ **智能分组** - 按优先级/新增/全部分组
- ✅ **进度显示** - 实时显示运行状态
- ✅ **结果汇总** - 自动生成运行报告
- ✅ **并行支持** - 多GPU并行运行（可选）
- ✅ **错误处理** - 超时和异常自动处理

---

## 🚀 快速开始

### 方式1: 交互式模式（最简单）⭐

```bash
python experiments/camtd3_strategy_suite/run_batch_experiments.py
```

会出现友好的菜单：
```
可用的实验:
------------------------------------------------------------------------------
#    实验名称                  优先级   配置数   预计时间(100轮)     标记
------------------------------------------------------------------------------
1    数据大小对比              高       5        1.5-2h            
2    车辆数量对比              高       5        1.5-2h            
3    本地资源对卸载影响        中       5        1.5-2h            
4    本地资源对成本影响        中       7        2-3h              
5    带宽对成本影响            中       7        2-3h              
6    边缘节点配置对比          高       6        1.8-2.5h          ⭐NEW
7    任务到达率对比            高       6        1.8-2.5h          ⭐NEW
8    移动速度对比              高       6        1.8-2.5h          ⭐NEW
------------------------------------------------------------------------------

选择方式:
  1. 输入实验编号（用逗号分隔，如: 1,2,6）
  2. 输入 'all' 运行所有实验
  3. 输入 'high' 运行高优先级实验
  4. 输入 'new' 运行新增实验

请选择要运行的实验: ▊
```

然后选择模式：
```
运行模式:
  quick: 快速测试（10轮，约10-20分钟/实验）
  medium: 中等测试（100轮，约1.5-3小时/实验）
  full: 完整实验（500轮，约7-15小时/实验）

选择运行模式 (quick/medium/full): ▊
```

### 方式2: 命令行模式（快速高效）

#### 场景1: 快速测试所有实验
```bash
python run_batch_experiments.py --mode quick --all
```

#### 场景2: 完整运行高优先级实验
```bash
python run_batch_experiments.py --mode full --high-priority
```

#### 场景3: 测试新增的3个实验
```bash
python run_batch_experiments.py --mode medium --new-only
```

#### 场景4: 运行指定实验
```bash
python run_batch_experiments.py --mode medium --experiments 1,2,6,7,8
```

#### 场景5: 并行运行（多GPU）
```bash
# 最多同时运行3个实验
python run_batch_experiments.py --mode medium --all --parallel 3
```

#### 场景6: 静默模式（减少输出）
```bash
python run_batch_experiments.py --mode quick --all --silent
```

---

## 📋 参数说明

### 运行模式 (`--mode`)
| 模式 | 轮数 | 单实验时间 | 适用场景 |
|------|------|-----------|----------|
| `quick` | 10轮 | 10-20分钟 | 快速验证流程 |
| `medium` | 100轮 | 1.5-3小时 | 中等质量测试 |
| `full` | 500轮 | 7-15小时 | 完整论文实验 |

### 实验选择
| 参数 | 说明 | 示例 |
|------|------|------|
| `--all` | 运行所有8个实验 | `--all` |
| `--high-priority` | 仅高优先级(1,2,6,7,8) | `--high-priority` |
| `--new-only` | 仅新增实验(6,7,8) | `--new-only` |
| `--experiments` | 指定实验编号 | `--experiments 1,2,6` |

### 其他参数
| 参数 | 说明 | 默认值 |
|------|------|--------|
| `--seed` | 随机种子 | 42 |
| `--suite-id` | 结果标识符前缀 | 自动生成 |
| `--parallel N` | 并行运行N个实验 | 顺序运行 |
| `--silent` | 静默模式 | 显示输出 |

---

## 📊 运行示例

### 示例1: 论文完整实验（推荐）

```bash
# 运行高优先级的5个实验（完整模式）
# 预计时间: 35-60小时
python run_batch_experiments.py \
    --mode full \
    --high-priority \
    --seed 42 \
    --suite-id paper_final
```

### 示例2: 快速全面验证

```bash
# 快速测试所有8个实验
# 预计时间: 1.5-3小时
python run_batch_experiments.py \
    --mode quick \
    --all \
    --suite-id quick_verify
```

### 示例3: 新增实验重点测试

```bash
# 中等强度测试3个新增实验
# 预计时间: 5-8小时
python run_batch_experiments.py \
    --mode medium \
    --new-only \
    --seed 42 \
    --suite-id new_experiments
```

### 示例4: 并行加速（多GPU）

```bash
# 在3个GPU上并行运行
# 时间可缩短至原来的1/3
python run_batch_experiments.py \
    --mode medium \
    --all \
    --parallel 3 \
    --silent
```

---

## 📈 运行过程

### 顺序运行示例输出

```
======================================================================
                         开始顺序运行实验
======================================================================

[1/5] 运行实验: 数据大小对比
  脚本: run_data_size_comparison.py
  配置数: 5, 每配置轮数: 100
  预计时间: 1.5-2h (基于100轮)
----------------------------------------------------------------------
✓ 完成! 用时: 95.3 分钟

[2/5] 运行实验: 车辆数量对比
  脚本: run_vehicle_count_comparison.py
  配置数: 5, 每配置轮数: 100
  预计时间: 1.5-2h (基于100轮)
----------------------------------------------------------------------
✓ 完成! 用时: 98.7 分钟

...
```

### 完成后自动显示摘要

```
======================================================================
                            运行摘要
======================================================================

Suite ID: batch_medium_20231029_123456
运行模式: medium (100 轮/配置)

总实验数: 5
  ✓ 成功: 5
  
总用时: 8.23 小时 (494.0 分钟)

详细结果:
--------------------------------------------------------------------------------
#    实验名称                     状态       用时           
--------------------------------------------------------------------------------
1    数据大小对比                 成功       95.3 min       
2    车辆数量对比                 成功       98.7 min       
6    边缘节点配置对比             成功       102.1 min      
7    任务到达率对比               成功       99.5 min      
8    移动速度对比                 成功       98.4 min      
--------------------------------------------------------------------------------

结果位置:
  results/parameter_sensitivity/batch_medium_20231029_123456_*/
  - summary.json (汇总数据)
  - *.png (对比图表)

批量运行摘要已保存: results/parameter_sensitivity/batch_medium_20231029_123456_batch_summary.json
```

---

## 🎯 推荐使用策略

### 第一次使用

1. **快速验证**（30分钟）
   ```bash
   python run_batch_experiments.py --mode quick --experiments 2
   # 先测试1个实验，确认环境正常
   ```

2. **新增实验快速测试**（2小时）
   ```bash
   python run_batch_experiments.py --mode quick --new-only
   # 测试3个新增实验
   ```

3. **全面快速测试**（3小时）
   ```bash
   python run_batch_experiments.py --mode quick --all
   # 测试所有8个实验
   ```

### 论文准备阶段

1. **高优先级中等测试**（10-15小时）
   ```bash
   python run_batch_experiments.py --mode medium --high-priority
   # 运行5个高优先级实验
   ```

2. **完整实验**（50-70小时）
   ```bash
   # 建议在服务器上运行
   nohup python run_batch_experiments.py \
       --mode full \
       --all \
       --seed 42 \
       --suite-id paper_final_v1 \
       --silent > batch_run.log 2>&1 &
   ```

---

## 💡 高级技巧

### 1. 后台运行（Linux/Mac）

```bash
# 后台运行并保存日志
nohup python run_batch_experiments.py \
    --mode full --all --silent \
    > batch_run.log 2>&1 &

# 查看日志
tail -f batch_run.log
```

### 2. Windows后台运行

```powershell
# 使用start命令
start /B python run_batch_experiments.py --mode full --all --silent > batch_run.log 2>&1
```

### 3. 分批运行（避免太长时间）

```bash
# 第一批: 高优先级（1,2,6,7,8）
python run_batch_experiments.py --mode full --high-priority --suite-id batch1

# 第二批: 其他实验（3,4,5）
python run_batch_experiments.py --mode full --experiments 3,4,5 --suite-id batch2
```

### 4. 监控进度

```bash
# 查看运行中的Python进程
ps aux | grep run_batch_experiments

# 查看GPU使用
nvidia-smi

# 查看生成的结果
ls -lh results/parameter_sensitivity/
```

---

## 🔧 故障排查

### 问题1: 某个实验失败

**查看批量摘要**:
```bash
cat results/parameter_sensitivity/batch_*_batch_summary.json
```

**手动重跑失败的实验**:
```bash
python experiments/camtd3_strategy_suite/run_data_size_comparison.py \
    --episodes 100 --seed 42
```

### 问题2: 并行运行GPU显存不足

**解决**: 减少并行数
```bash
# 从 --parallel 3 改为 --parallel 2
python run_batch_experiments.py --mode medium --all --parallel 2
```

### 问题3: 运行时间过长

**解决**: 先用quick模式测试
```bash
# 快速模式仅10轮
python run_batch_experiments.py --mode quick --all
```

---

## 📦 输出文件

### 目录结构

```
results/parameter_sensitivity/
├── batch_medium_20231029_123456_batch_summary.json    # 批量运行总摘要
├── batch_medium_20231029_123456_1_数据大小对比/
│   ├── summary.json
│   ├── data_*.json
│   └── data_size_vs_*.png
├── batch_medium_20231029_123456_2_车辆数量对比/
│   └── ...
└── ...
```

### 批量摘要JSON格式

```json
{
  "suite_id": "batch_medium_20231029_123456",
  "mode": "medium",
  "episodes": 100,
  "total_experiments": 5,
  "successful": 5,
  "failed": 0,
  "total_time_seconds": 29640.5,
  "results": [
    {
      "exp_id": 1,
      "name": "数据大小对比",
      "success": true,
      "elapsed_time": 5718.3,
      ...
    },
    ...
  ],
  "timestamp": "2023-10-29T12:34:56"
}
```

---

## ✅ 检查清单

使用批量工具前：
- [ ] 确认在项目根目录 `D:\VEC_mig_caching`
- [ ] 确认conda环境已激活
- [ ] 确认有足够的磁盘空间（建议≥10GB）
- [ ] 确认GPU可用（如使用并行）

运行过程中：
- [ ] 监控GPU使用率
- [ ] 定期检查结果目录
- [ ] 注意错误信息

运行完成后：
- [ ] 查看批量摘要JSON
- [ ] 检查所有图表是否生成
- [ ] 验证数据完整性

---

## 🎉 开始使用

**最简单的方式**:
```bash
python experiments/camtd3_strategy_suite/run_batch_experiments.py
```

按照菜单提示操作即可！ 🚀

