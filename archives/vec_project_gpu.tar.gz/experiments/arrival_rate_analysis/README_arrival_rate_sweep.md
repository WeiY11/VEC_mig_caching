# TD3任务到达率敏感性分析实验

## 📋 实验说明

该脚本用于测试不同任务到达率(arrival_rate)对TD3算法性能的影响，是参数敏感性分析的重要组成部分。

### 🎯 实验目标

- **核心指标**: 平均步奖励 (ave_reward_per_step)
- **优化目标**: 时延 + 能耗
- **测试参数**: 任务到达率 (1.0 - 3.5 tasks/s)

### 📊 当前配置

```
默认任务到达率: 2.5 tasks/s (12车辆高负载场景)
车辆数: 12辆
算法: TD3
```

## 🚀 快速开始

### 1. 快速测试（约10分钟）

```bash
python experiments/run_td3_arrival_rate_sweep.py --episodes 50
```

### 2. 标准实验（约1-2小时）

```bash
python experiments/run_td3_arrival_rate_sweep.py --episodes 200
```

### 3. 完整实验（约3-4小时，论文用）

```bash
python experiments/run_td3_arrival_rate_sweep.py --episodes 800
```

## 🔧 自定义参数

### 自定义到达率范围

```bash
# 测试低负载场景
python experiments/run_td3_arrival_rate_sweep.py --rates 0.5 1.0 1.5 2.0 --episodes 200

# 测试高负载场景
python experiments/run_td3_arrival_rate_sweep.py --rates 2.5 3.0 3.5 4.0 --episodes 200

# 精细化测试
python experiments/run_td3_arrival_rate_sweep.py --rates 1.0 1.2 1.5 1.8 2.0 2.2 2.5 2.8 3.0 --episodes 200
```

### 指定车辆数

```bash
# 8车辆场景
python experiments/run_td3_arrival_rate_sweep.py --num-vehicles 8 --episodes 200

# 16车辆场景
python experiments/run_td3_arrival_rate_sweep.py --num-vehicles 16 --episodes 800
```

### 指定随机种子

```bash
# 可重复实验
python experiments/run_td3_arrival_rate_sweep.py --seed 42 --episodes 200

# 多种子对比
python experiments/run_td3_arrival_rate_sweep.py --seed 2025 --episodes 200
```

### 自定义输出目录

```bash
python experiments/run_td3_arrival_rate_sweep.py \
    --output-dir results/custom_arrival_rate \
    --episodes 200
```

## 📈 查看结果

### 跳过训练，仅生成图表

如果已经完成训练，只想重新生成图表：

```bash
python experiments/run_td3_arrival_rate_sweep.py --skip-training
```

### 结果文件说明

```
results/parameter_sensitivity/arrival_rate/
├── arrival_rate_1.0_results.json          # 各个到达率的详细结果
├── arrival_rate_1.5_results.json
├── arrival_rate_2.0_results.json
├── ...
├── arrival_rate_comparison_YYYYMMDD_HHMMSS.png  # 对比图表
└── arrival_rate_summary_YYYYMMDD_HHMMSS.json    # 汇总数据
```

### 结果解读

**对比图表包含4个子图：**

1. **(a) 平均步奖励 vs 任务到达率**
   - 核心优化目标：`-(时延 + 能耗)`
   - 数值越高越好（负值越接近0越好）
   - 反映系统整体性能

2. **(b) 平均时延 vs 任务到达率**
   - 系统响应速度
   - 包含传输时延 + 计算时延
   - 数值越低越好

3. **(c) 平均能耗 vs 任务到达率**
   - 系统总能耗
   - 包含传输能耗 + 计算能耗
   - 数值越低越好

4. **(d) 丢弃任务数 vs 任务到达率**
   - 系统负载承受能力
   - 数值越低越好
   - 过高表示系统过载

## 📊 实验示例

### 示例1: 完整参数扫描

```bash
# 测试6个到达率水平
python experiments/run_td3_arrival_rate_sweep.py \
    --rates 1.0 1.5 2.0 2.5 3.0 3.5 \
    --episodes 800 \
    --num-vehicles 12 \
    --seed 42
```

**预期结果：**
- 低到达率(1.0-2.0)：奖励较高，时延和能耗较低
- 中到达率(2.0-2.5)：性能平衡点
- 高到达率(2.5-3.5)：系统负载增加，性能下降

### 示例2: 多车辆场景对比

```bash
# 8车辆 - 低负载
python experiments/run_td3_arrival_rate_sweep.py \
    --num-vehicles 8 \
    --rates 1.0 1.5 2.0 2.5 \
    --episodes 800 \
    --output-dir results/arrival_rate_8v

# 12车辆 - 中负载
python experiments/run_td3_arrival_rate_sweep.py \
    --num-vehicles 12 \
    --rates 1.0 1.5 2.0 2.5 3.0 3.5 \
    --episodes 800 \
    --output-dir results/arrival_rate_12v

# 16车辆 - 高负载
python experiments/run_td3_arrival_rate_sweep.py \
    --num-vehicles 16 \
    --rates 1.5 2.0 2.5 3.0 3.5 4.0 \
    --episodes 800 \
    --output-dir results/arrival_rate_16v
```

## 🔬 论文用实验建议

### 推荐配置

```bash
# 标准12车辆场景（主要结果）
python experiments/run_td3_arrival_rate_sweep.py \
    --rates 1.0 1.5 2.0 2.5 3.0 3.5 \
    --episodes 800 \
    --num-vehicles 12 \
    --seed 42 \
    --output-dir results/paper/arrival_rate_12v

# 多种子验证（可选）
for seed in 42 2025 3407; do
    python experiments/run_td3_arrival_rate_sweep.py \
        --rates 1.0 1.5 2.0 2.5 3.0 3.5 \
        --episodes 800 \
        --num-vehicles 12 \
        --seed $seed \
        --output-dir results/paper/arrival_rate_seed_${seed}
done
```

### 图表质量

生成的PNG图表分辨率为300 DPI，可直接用于论文投稿。

## ⚙️ 技术细节

### 环境变量传递

脚本通过环境变量 `TASK_ARRIVAL_RATE` 向 `train_single_agent.py` 传递参数：

```python
env['TASK_ARRIVAL_RATE'] = str(arrival_rate)
```

### 指标提取

- 使用最后50轮的平均值作为稳定期性能
- 包含标准差用于评估稳定性
- 完整历史数据保存用于详细分析

### 性能优化

- 使用 `--silent-mode` 减少输出
- 自动管理文件路径
- 支持断点续传（`--skip-training`）

## 🐛 常见问题

### Q1: 训练时间太长怎么办？

**A:** 减少轮次或到达率测试点：
```bash
# 快速测试：只测试3个点，50轮
python experiments/run_td3_arrival_rate_sweep.py \
    --rates 1.5 2.5 3.5 \
    --episodes 50
```

### Q2: 如何只重新生成图表？

**A:** 使用 `--skip-training` 参数：
```bash
python experiments/run_td3_arrival_rate_sweep.py --skip-training
```

### Q3: 如何比较不同车辆数的结果？

**A:** 使用不同的输出目录，然后手动比较：
```bash
# 运行不同车辆数的实验
python experiments/run_td3_arrival_rate_sweep.py --num-vehicles 8 --output-dir results/arr_8v --episodes 200
python experiments/run_td3_arrival_rate_sweep.py --num-vehicles 12 --output-dir results/arr_12v --episodes 200
python experiments/run_td3_arrival_rate_sweep.py --num-vehicles 16 --output-dir results/arr_16v --episodes 200

# 查看各自的结果图表
```

### Q4: 训练中断了怎么办？

**A:** 已完成的到达率结果会保存，可以手动修改 `--rates` 参数只运行未完成的：
```bash
# 假设1.0, 1.5已完成，只运行剩余的
python experiments/run_td3_arrival_rate_sweep.py \
    --rates 2.0 2.5 3.0 3.5 \
    --episodes 800
```

## 📚 相关文档

- [train_single_agent.py](../train_single_agent.py) - TD3训练脚本
- [config/system_config.py](../config/system_config.py) - 系统配置
- [paper_ending.tex](../docs/paper_ending.tex) - 理论模型

## 📝 引用说明

如果在论文中使用该实验结果，建议描述：

```latex
我们测试了任务到达率从1.0到3.5 tasks/s对TD3算法性能的影响。
在12车辆场景下，每个到达率配置训练800轮。
实验结果表明，当到达率在1.5-2.5 tasks/s范围内时，
系统能够在时延和能耗之间实现良好的平衡。
```

## ⏱️ 预计运行时间

| 配置 | 轮次 | 到达率点数 | 预计时间 |
|------|------|-----------|---------|
| 快速测试 | 50 | 6 | ~10分钟 |
| 标准实验 | 200 | 6 | ~1-2小时 |
| 完整实验 | 800 | 6 | ~3-4小时 |
| 精细实验 | 800 | 10 | ~5-6小时 |

*注：实际时间取决于硬件性能*

## 🎉 示例输出

```
================================================================================
🔬 TD3任务到达率敏感性分析实验
================================================================================
📋 实验配置:
   - 算法: TD3
   - 到达率范围: [1.0, 1.5, 2.0, 2.5, 3.0, 3.5] tasks/s
   - 训练轮次: 200
   - 车辆数: 12
   - 随机种子: 42
   - 输出目录: results/parameter_sensitivity/arrival_rate
================================================================================

================================================================================
🚀 开始训练: arrival_rate=1.0 tasks/s
================================================================================
...
✅ 训练完成: arrival_rate=1.0
💾 结果已保存: results/parameter_sensitivity/arrival_rate/arrival_rate_1.0_results.json
...

================================================================================
📊 实验结果汇总
================================================================================
    到达率 |   平均步奖励 |   平均时延 |   平均能耗 |     丢弃任务
--------------------------------------------------------------------------------
       1.0 |     -0.2345 |     0.1234 |     0.0987 |       0.12
       1.5 |     -0.2876 |     0.1456 |     0.1123 |       0.45
       2.0 |     -0.3421 |     0.1789 |     0.1345 |       1.23
       2.5 |     -0.4123 |     0.2134 |     0.1567 |       2.45
       3.0 |     -0.5234 |     0.2567 |     0.1789 |       4.56
       3.5 |     -0.6345 |     0.3012 |     0.2012 |       7.89
================================================================================

📊 对比图表已保存: results/parameter_sensitivity/arrival_rate/arrival_rate_comparison_20251031_123456.png
💾 汇总报告已保存: results/parameter_sensitivity/arrival_rate/arrival_rate_summary_20251031_123456.json

================================================================================
✅ 实验完成!
================================================================================
📁 结果目录: results/parameter_sensitivity/arrival_rate
📊 共完成 6 个实验
================================================================================
```

